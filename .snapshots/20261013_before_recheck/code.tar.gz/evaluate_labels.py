#!/usr/bin/env python3
"""사람이 만든 정답 라벨(test_label.json)과 모델 결과를 대조해 성능을 잰다.

축을 따로 본다 - 하나로 뭉치면 무엇이 문제인지 안 보인다.

목표 지표 (이 셋으로 파이프라인의 좋고 나쁨을 판단한다):

  1) VERDICT     Normal/Special 이진 판정. categories 가 비었는가로 파생되며,
                 파이프라인의 판정 규칙과 정확히 같다.
  2) CATEGORIES  멀티라벨 F1. "정답 n개 중 m개" (m/n) 를 쓰지 않는 이유는
                 그 식의 분모가 정답 쪽이라 오탐에 벌점이 없기 때문이다 -
                 정답이 [Jaywalking] 인데 모델이 4개를 다 찍어도 1.0 이 되어,
                 "전부 찍기"가 최적 전략이 되어버린다. F1 은 precision 을
                 함께 보므로 그 문제가 없다.
  3) SCORES      묶음(Dynamic object / Driving environment)마다 클립당
                 0~4 점수 하나. 0 은 "그 묶음의 특수 카테고리 없음"이라
                 Normal 클립도 채점에 들어간다. 묶음마다 표를 따로 내고,
                 묶음 점수와 카테고리 목록이 어긋난 건수도 센다.
  5) WEATHER     날씨 4축(조도/강수/노면/대기가림). 목표 지표와
                 같은 방식으로 채점한다. 등급과 달리 edge-case 여부와 무관한
                 축이라(평범한 클립도 비가 오면 높다) SPECIAL 만 따로 내지
                 않고 전체만 내며, 대신 4축 요약표를 붙여 어느 축이 틀리는지
                 나란히 본다.

유병률 보정:
  정답 표본은 normal:special = 50:50 이지만 실제 데이터는 약 81:19 다.
  precision 은 표본에 normal 이 몇 개 들어있느냐에 직접 영향을 받으므로,
  50:50 표본의 precision 을 그대로 보고하면 실제보다 크게 부풀려진다.
  recall 과 specificity 는 표본 비율과 무관하므로, 그 둘로 실제 유병률에서의
  precision 을 다시 계산해 함께 보여준다.

기준선(baseline):
  정수 축은 "항상 최빈값" 으로 찍어도 MSE 가 꽤 낮게 나온다(실측: 난이도
  4축은 정답의 45~87% 가 0점이라 전부 0 으로 찍어도 그럴듯해 보인다).
  그래서 최빈값 예측의 MSE 를 함께 내고, 모델이 그걸 이기는지 본다.
  이기지 못하면 모델이 그 축을 실제로 판단하는 것이 아니다.
  이 비교가 실제로 중요한 곳은 목표 지표인 5) WEATHER 다.

Usage:
  python evaluate_labels.py --run-dir results/20260812_135056_videoC
  python evaluate_labels.py --run-dir <dir> --labels test_label.json
"""
import argparse
import glob
import json
from collections import Counter
from pathlib import Path

import pandas as pd

from config import SCENE_JSON as CONFIG_SCENE_JSON, LABELS_JSON
from constrained_tier import TIER_VALUES, GROUP_RUBRICS, group_values, group_key
from prompts import DIFFICULTY_AXES, DIFFICULTY_MIN, DIFFICULTY_MAX

# 난이도 축의 눈금. 등급(TIER_VALUES)과 따로 두는 이유는 두 척도가 서로
# 독립으로 바뀔 수 있어서다 - 한쪽을 고칠 때 다른 쪽이 조용히 따라가면 안 된다.
DIFFICULTY_VALUES = tuple(range(DIFFICULTY_MIN, DIFFICULTY_MAX + 1))

ROOT = Path(__file__).resolve().parent
# 기본값은 config.py 한 곳에서만 정한다 - 여기서 따로 들고 있다가 예전에
# aggregate_clip.py 는 D, 이쪽은 C 로 같은 실행을 다르게 해석한 적이 있다.
DEFAULT_LABELS = LABELS_JSON

# 실제 데이터셋의 special 비율. 유병률 보정에 쓴다.
# 실측: 1,998 클립 중 375 건이 edge-case (20260812 전량 실행).
DEFAULT_PREVALENCE = 375 / 1998


def load_labels(path: Path):
    """정답 라벨 -> {uuid: {categories, scores, note, <날씨 4축>}}.

    categories 는 그 클립에 나온 특수 카테고리 이름 리스트다. 옛 라벨의
    {이름: 점수} 딕셔너리도 받되 이름만 쓴다.

    scores 는 묶음 점수 {묶음 이름: 0~4} - 라벨 최상위의 "Dynamic object",
    "Driving environment" 키(constrained_tier.GROUP_RUBRICS)에서 읽는다.
    키가 없거나 null/-1 이면 아직 안 매긴 것이라 빠진다. 0~4 밖의 정수는
    mismatches["out_of_range"] 에 모아 돌려주고 채점에서 뺀다.

    날씨는 없어도 건너뛰지 않는다 - 예전 라벨 파일에는 weather 키가
    아예 없고, 그것 때문에 클립을 빼면 1~3 번 채점의 표본까지 조용히 줄어든다.
    없는 축은 None 으로 두고 5) 섹션에서만 제외한다.
    """
    data = json.loads(path.read_text(encoding="utf-8"))
    clips = data.get("clips", data)
    out, skipped = {}, []
    mismatches = {"out_of_range": []}
    for uuid, v in clips.items():
        if not isinstance(v, dict):
            continue
        raw = v.get("categories")
        if raw is None:
            skipped.append(uuid)
            continue
        scores = {}
        for g in GROUP_RUBRICS:
            n = _int_or_none(v.get(g))
            if n is None or n == -1:
                continue
            if n not in group_values(g):
                mismatches["out_of_range"].append((uuid, g, n))
                continue
            scores[g] = n
        rec = {
            "categories": set(raw),
            "scores": scores,
            "note": v.get("note", ""),
        }
        # 날씨 점수는 {"weather": {...}} 한 곳에서만 읽는다. 옛 라벨의
        # "difficulty" 키와 최상위 평평한 형식은 지원을 끊었다 - 라벨 파일을
        # 모두 "weather" 로 옮겼고(2026-10-07), 키가 둘이던 동안 채점이
        # 엉뚱한 쪽만 읽어 5) WEATHER 절이 통째로 빠졌다(20261006_203002).
        weather = _weather_of(v)
        for key, _ in DIFFICULTY_AXES:
            rec[key] = _int_or_none(weather.get(key))
        out[uuid] = rec
    return out, data.get("_meta", {}), skipped, mismatches


def restrict_to_group(labels: dict, run_cfg: dict, scene_path: Path):
    """실행이 상위 카테고리 하나만 다뤘으면(--group) GT 를 그 범위로 줄인다.

    Dynamic object 만 찾은 실행을 GT 전체로 채점하면, 그 실행이 애초에 찾을
    수 없던 Driving environment 카테고리가 전부 놓침이 되고, 환경 카테고리만
    있는 클립은 Special 인데 Normal 로 판정한 것으로 세진다. 그래서 GT 의
    카테고리와 묶음 점수를 실행이 다룬 상위 카테고리로 줄인다(labels 를 바로
    고친다). 반환: (group, 뺀 카테고리 수, 그 결과 Normal 이 된 클립 수).
    """
    group = (((run_cfg or {}).get("key") or {}).get("group")) or "all"
    if group == "all" or not Path(scene_path).exists():
        return group, 0, 0
    scene = json.loads(Path(scene_path).read_text(encoding="utf-8"))
    keep = {c["name"] for s in scene["special"]["scenarios"]
            if group_key(s["name"]) == group for c in s["categories"]}
    n_drop = n_normal = 0
    for rec in labels.values():
        drop = rec["categories"] - keep
        if drop:
            n_drop += len(drop)
            rec["categories"] = rec["categories"] & keep
            if not rec["categories"]:
                n_normal += 1
        rec["scores"] = {g: v for g, v in rec["scores"].items()
                         if group_key(g) == group}
    return group, n_drop, n_normal


def _weather_of(v: dict) -> dict:
    """라벨 한 건의 날씨 4축 딕셔너리({"illumination": 0, ...}). 없으면 {}.

    비/눈/안개 태그 목록은 "rain_snow_fog" 에 따로 있다.
    """
    w = v.get("weather")
    return w if isinstance(w, dict) else {}


def load_results(run_dir: Path):
    """모델 결과 CSV(샤드 병합) -> {uuid: {categories, scores, <날씨>}}.

    group_scores 열은 "Dynamic object=2|Driving environment=0" 형태다.
    점수를 끈 실행이나 묶음 점수 이전(카테고리별 점수) 실행에는 이 열이
    없거나 비어 있어 scores 가 비고, 그러면 3) 섹션이 통째로 빠진다.
    """
    files = sorted(glob.glob(str(run_dir / "clip_results*.csv")))
    if not files:
        return {}
    df = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
    df = df.drop_duplicates(subset="uuid", keep="first")
    out = {}
    for _, r in df.iterrows():
        cats = r.get("categories")
        cats = set(str(cats).split("|")) if isinstance(cats, str) and cats.strip() else set()
        raw = r.get("group_scores")
        scores = {}
        if isinstance(raw, str) and raw.strip():
            for part in raw.split("|"):
                if "=" not in part:
                    continue
                k, _, v = part.rpartition("=")
                n = _int_or_none(v)
                if k.strip() and n is not None:
                    scores[k.strip()] = n
        rec = {"categories": cats, "scores": scores}
        # --weather 를 끈 실행에는 이 칸이 아예 없거나 빈 값이다.
        for key, _name in DIFFICULTY_AXES:
            rec[key] = _int_or_none(r.get(key))
        out[str(r["uuid"])] = rec
    return out


def _int_or_none(v):
    try:
        if pd.isna(v):
            return None
        return int(v)
    except (TypeError, ValueError):
        return None


def prf(tp, fp, fn):
    p = tp / (tp + fp) if (tp + fp) else 0.0
    r = tp / (tp + fn) if (tp + fn) else 0.0
    f = 2 * p * r / (p + r) if (p + r) else 0.0
    return p, r, f


def f1_set(truth: set, pred: set) -> float:
    """멀티라벨 한 클립의 F1. 둘 다 비어 있으면 1.0 (정답을 맞힌 것)."""
    if not truth and not pred:
        return 1.0
    tp = len(truth & pred)
    return prf(tp, len(pred - truth), len(truth - pred))[2]


def confusion(pairs, values=None, rows=None):
    """[(truth, pred), ...] -> 문자열 혼동행렬 (행 합계 total 포함).

    values 를 안 주면 TIER_VALUES 를 쓴다 - 등급 개수가 바뀌어도(1~3 -> 1~4)
    표가 따라 넓어지도록 한 곳만 보게 한다.
    행 합계를 같이 내는 이유는 "정답 3인 20건 중 몇 건을 2로 봤나" 같은
    질문이 이 표를 읽는 주된 목적이라, 분모가 옆에 있어야 바로 읽히기 때문.

    Acc 는 그 행의 재현율(대각선/행 합계)이다. 전체 정확도 한 줄로는
    "어느 등급을 못 맞히는가"가 안 보인다 - 정답이 한 등급에 쏠려 있으면
    그 등급만 맞혀도 전체 수치가 좋게 나오기 때문이다(실측: 난이도 4축은
    정답의 45~87%가 0점). 행별로 나눠 두면 쏠린 등급과 희소한 등급의
    성능이 갈라져 보인다. 행 합계가 0 이면(그 등급의 정답이 없으면)
    비율을 낼 수 없으므로 '-' 로 둔다.

    rows 를 주면 행(정답)은 그 눈금만 그린다. 카테고리 점수는 정답이 1~4
    뿐인데 예측에는 0(못 찾음)이 있어, 열과 행의 폭이 다르다.
    """
    if values is None:
        values = TIER_VALUES
    if rows is None:
        rows = values
    c = Counter(pairs)
    w = 9                                    # 열 너비
    head = "       " + "".join(f"{'pred'+str(v):>{w}}" for v in values)
    lines = [head + f"{'total':>{w}}" + f"{'Acc':>{w}}"]
    for t in rows:
        row = "".join(f"{c.get((t, p), 0):>{w}}" for p in values)
        total = sum(c.get((t, p), 0) for p in values)
        acc = f"{c.get((t, t), 0) / total * 100:.1f}%" if total else "-"
        lines.append(f"  true{t}{row}{total:>{w}}{acc:>{w}}")
    return "\n".join(lines)


def _mse(pairs) -> float:
    """(정답, 예측) 쌍들의 평균제곱오차. 빈 리스트면 0."""
    return (sum((a - b) ** 2 for a, b in pairs) / len(pairs)) if pairs else 0.0


def tier_block(name, pairs, log, values=None, rows=None):
    """한 축(safety/rarity/난이도)의 MSE / 정확일치 / 혼동행렬 / 기준선.

    values 로 눈금을 넘기면 혼동행렬이 그 폭으로 그려진다. 안 주면 등급
    눈금(TIER_VALUES)을 쓴다 - 난이도는 DIFFICULTY_VALUES 를 넘긴다.

    MAE 대신 MSE 를 쓰는 이유: 오차 하나가 클수록 벌점을 더 준다 - 등급을
    1칸 틀리는 것과 3칸 틀리는 것(예: 정답 0인데 3으로 예측)은 안전/희귀도
    판단에서 심각도가 다른데 MAE 는 그 차이를 선형으로만 반영한다(1 vs 3).
    MSE 는 제곱이라 그 차이를 더 크게 반영한다(1 vs 9).
    """
    if not pairs:
        log(f"  (no comparable rows)")
        return
    n = len(pairs)
    mse = sum((t - p) ** 2 for t, p in pairs) / n
    exact = sum(t == p for t, p in pairs) / n
    # 기준선: 정답에서 가장 흔한 등급으로 전부 찍었을 때.
    # baseline 값 자체는 MSE 로 바꿔도 최빈값(mode) 그대로 쓴다 - "항상 같은
    # 값을 찍는 가장 단순한 전략을 이기는가"라는 비교 취지를 유지하기
    # 위해서다. MSE 를 엄밀히 최소화하는 값은 평균이지만, 이산 등급에서
    # 평균은 "항상 2.3 을 찍는다"처럼 존재하지 않는 값이 되어 baseline 의
    # 직관("가장 흔한 답을 그냥 찍으면 어떻게 되는가")과 어긋난다.
    mode = Counter(t for t, _ in pairs).most_common(1)[0][0]
    base_mse = sum((t - mode) ** 2 for t, _ in pairs) / n
    base_exact = sum(t == mode for t, _ in pairs) / n

    log(f"  n              : {n}")
    log(f"  MSE            : {mse:.3f}      baseline(always {mode}): {base_mse:.3f}"
        f"   {'BEATS' if mse < base_mse else 'DOES NOT BEAT'} baseline")
    log(f"  exact match    : {exact:6.1%}    baseline: {base_exact:6.1%}")
    log(f"  within +-1     : {sum(abs(t-p)<=1 for t,p in pairs)/n:6.1%}")
    log("")
    log(confusion(pairs, values, rows))


def write_category_lists(run_dir, per_cat, log):
    """카테고리별 TP/FP/FN 클립 목록을 <run-dir>/categories/<name>/ 에 쓴다.

    왜 필요한가: 표의 숫자(P/R/F1)는 어느 카테고리가 문제인지는 알려주지만
    "어떤 클립에서" 틀렸는지는 알려주지 않는다. 오분류를 눈으로 확인하려면
    매번 CSV 와 라벨을 대조해야 했다. uuid 목록을 파일로 떨궈두면 시각화
    폴더(viz/)에서 바로 찾아볼 수 있다.

    TP = 정답에도 있고 예측에도 있음
    FP = 정답에는 없는데 예측함 (정답이 Normal 이거나 다른 카테고리인 경우)
    FN = 정답에는 있는데 예측 못 함

    카테고리명에 / 가 들어가면 경로가 깨지므로 _ 로 바꾼다. 폴더는 실행할
    때마다 새로 쓰되(덮어쓰기), 예전 실행의 목록을 지우지는 않는다.
    """
    base = Path(run_dir) / "categories"
    n_files = 0
    for cat, buckets in sorted(per_cat.items()):
        safe = cat.replace("/", "_").strip() or "_unnamed"
        d = base / safe
        d.mkdir(parents=True, exist_ok=True)
        for kind in ("TP", "FP", "FN"):
            uuids = sorted(buckets[kind])
            # 0건이어도 빈 파일을 만든다 - 파일이 없는 것과 0건인 것을
            # 구분할 수 있어야 "아직 안 돌렸나?" 를 되묻지 않는다.
            (d / f"{kind}.txt").write_text(
                "".join(u + "\n" for u in uuids), encoding="utf-8")
            n_files += 1
    log(f"  [saved] {base}/  ({len(per_cat)} categories, {n_files} files)")


def log_run_config(run_dir, log):
    """<run-dir>/run_config.json 의 주요 설정을 로그 머리에 찍는다.

    edge_case_mining.py 의 샤드 0 이 남긴 파일이다. 없으면(이 기능 이전에
    돈 실행이거나 클립 모드가 아니면) 조용히 넘어간다 - 옛 결과를
    --eval-only 로 다시 채점하는 길을 막지 않기 위해서다.
    """
    path = Path(run_dir) / "run_config.json"
    if not path.exists():
        log("[info] config  : (run_config.json 없음 - 이 기능 이전 실행)")
        return None
    try:
        cfg = json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as e:
        log(f"[warn] run_config.json 읽기 실패: {e}")
        return None

    key = dict(cfg.get("key", {}))
    # gt_labels 를 key 에 넣기 전에 돈 실행은 argv 에만 있다. 거기서 주워
    # 온다 - 옛 실행 폴더를 --eval-only 로 다시 채점할 때도 보이게.
    if "gt_labels" not in key:
        key["gt_labels"] = cfg.get("argv", {}).get("gt_labels")
    # 메모가 있으면 가장 먼저 - 설정 나열보다 "무엇을 시험한 실행인가" 가
    # 먼저 눈에 들어와야 한다.
    if key.get("memo"):
        log(f"[info] MEMO    : {key['memo']}")
    if cfg.get("timestamp"):
        log(f"[info] run at  : {cfg['timestamp']}")
    log(f"[info] model   : {key.get('model','?')}")
    # 카테고리 정의와 GT 라벨은 성능 숫자를 좌우하는데도 파일명이 비슷해
    # (scene_category_C/D, test_label/_D) 헷갈리기 쉽다 - 한 줄에 모아 둔다.
    log(f"[info] scene   : {key.get('scene_json','?')}"
        + (f"   gt-labels(viz): {key['gt_labels']}"
           if key.get("gt_labels") else "")
        # 라벨 경로가 같아도 내용이 바뀌었으면 이 지문이 달라진다
        + (f"  [sha {key['gt_labels_sha']}]"
           if key.get("gt_labels_sha") else ""))
    log(f"[info] frames  : {key.get('clip_fps','?')} fps  "
        f"max {key.get('clip_max_frames','?')}  "
        f"long side {key.get('clip_long_side','?')}px  "
        f"views {key.get('n_views','?')}"
        + ("  (video)" if key.get("video_input") else "  (image list)"))
    # 대조군 C/D 는 use_egomotion 이 꺼진 채로 돌므로, 그대로 찍으면
    # A(아무것도 없음)와 구분이 안 된다.
    _ego = (f"ablation-{key['ego_ablation'].upper()}"
            if key.get("ego_ablation") else _onoff(key.get("use_egomotion")))
    log(f"[info] facts   : egomotion={_ego}  "
        f"3dbbox={_onoff(key.get('use_3dbbox'))}  "
        f"tier-constraint={_onoff(key.get('constrain_tiers'))}  "
        f"timeline={_onoff(key.get('timeline'))}  "
        f"ego-track={_onoff(key.get('ego_track'))}  "
        f"traj={key.get('traj') or 'off'}  "
        f"header={key.get('header_style') or 'v1'}  "
        f"cat-scores={_scores_onoff(key)}  "
        f"difficulty={_onoff(key.get('difficulty'))}")
    return cfg


def _onoff(v):
    return "on" if v else "off" if v is not None else "?"


def _scores_onoff(key):
    """점수 단계 on/off. 옛 run_config 는 다른 이름으로 기록했다.

    safety_tiers/rarity_tiers 시절의 실행은 두 축을 따로 껐으므로, 하나라도
    켜져 있었으면 on 으로 읽는다 - 그때의 '점수 단계가 있었는가' 에 해당하는
    값이 그것이다.
    """
    if "score_categories" in key:
        return _onoff(key["score_categories"])
    old = [key[k] for k in ("safety_tiers", "rarity_tiers", "score_tiers")
           if k in key]
    return _onoff(any(old)) if old else "?"


# 샤드 로그에서 실패를 알아보는 표식. 파이썬 traceback 과, 죽지는 않았지만
# 결과를 버린 경우(CUDA OOM 등)를 함께 잡는다.
ERROR_MARKERS = ("Traceback (most recent call last)",
                 "CUDA out of memory",
                 "torch.OutOfMemoryError")


def scan_shard_errors(run_dir, log, max_show=3):
    """샤드 로그의 에러를 evaluation.log 에 옮겨 적는다.

    왜 필요한가: 샤드가 중간에 죽으면 그 샤드가 맡은 클립이 통째로 빠진
    채로 채점이 돌아간다. 숫자만 보면 "성능이 나쁘다" 로 읽히지만 실제로는
    데이터가 없는 것이라, 이 둘을 구분하지 못하면 A/B 비교가 무의미해진다.
    실제로 20260814_160229 실행이 8개 샤드 전부 KeyError 로 죽어 100클립
    중 8개만 채점됐는데, evaluation.log 에는 그 사실이 남지 않았다.

    traceback 의 마지막 줄(예외 종류와 메시지)이 원인을 가장 잘 요약하므로
    그것을 우선 보여주고, 전문은 로그 파일 경로로 안내한다.
    """
    run_dir = Path(run_dir)
    logs = sorted(glob.glob(str(run_dir / "run_shard_*.log")))
    if not logs:
        return []

    failed = []
    for p in logs:
        try:
            # \r 로 덮어쓰는 tqdm 진행바가 섞여 있어 줄바꿈으로 펴 준다
            text = Path(p).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        text = text.replace("\r", "\n")
        if not any(m in text for m in ERROR_MARKERS):
            continue
        lines = [ln.rstrip() for ln in text.splitlines() if ln.strip()]
        # traceback 마지막 줄 = "KeyError: 'speed_kmh'" 같은 요약
        detail = ""
        for i, ln in enumerate(lines):
            if ln.startswith("Traceback (most recent call last)"):
                tail = [x for x in lines[i:] if not x.startswith(("  ", "\t"))]
                detail = tail[-1] if tail else ""
        if not detail:
            for m in ERROR_MARKERS:
                hit = [ln for ln in lines if m in ln]
                if hit:
                    detail = hit[-1]
                    break
        failed.append((Path(p).name, detail or "(unknown error)"))

    if not failed:
        return []

    log("")
    log(f"[ERROR] {len(failed)}/{len(logs)} shard(s) FAILED - "
        f"결과가 일부만 채점됐을 수 있다:")
    for name, detail in failed[:max_show]:
        log(f"  {name}: {detail}")
    if len(failed) > max_show:
        log(f"  ... 외 {len(failed)-max_show}개 (같은 폴더의 run_shard_*.log 참고)")
    log("")
    return failed


class Tee:
    def __init__(self, path):
        self.f = open(path, "w", encoding="utf-8") if path else None

    def __call__(self, line=""):
        print(line)
        if self.f:
            self.f.write(line + "\n")

    def close(self):
        if self.f:
            self.f.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--run-dir", required=True,
                    help="모델 결과 폴더 (clip_results*.csv 가 있는 곳)")
    ap.add_argument("--labels", default=str(DEFAULT_LABELS))
    ap.add_argument("--prevalence", type=float, default=DEFAULT_PREVALENCE,
                    help="실제 데이터의 special 비율 (precision 보정용). "
                         f"기본 {DEFAULT_PREVALENCE:.3f} = 375/1998")
    ap.add_argument("--out", default=None,
                    help="결과를 저장할 로그 파일. 생략 시 <run-dir>/evaluation.log")
    ap.add_argument("--min-support", type=int, default=3,
                    help="카테고리별 지표를 따로 보여줄 최소 정답 건수 (기본 3)")
    args = ap.parse_args()

    run_dir = Path(args.run_dir)
    labels, meta, skipped, mismatches = load_labels(Path(args.labels))
    results = load_results(run_dir)
    log = Tee(Path(args.out) if args.out else run_dir / "evaluation.log")

    # 결과가 통째로 없는 경우 - 채점할 게 없어도 로그는 남긴다. 여기서 그냥
    # 돌아가 버리면 폴더에 evaluation.log 조차 없어서, 나중에 "왜 아무것도
    # 없지" 를 run_shard_*.log 를 뒤져야만 알 수 있다.
    if not results:
        log(f"[ERROR] no clip_results*.csv in {run_dir}")
        log(f"[info] labels  : {args.labels}  ({len(labels)} clips)")
        log_run_config(run_dir, log)
        if not scan_shard_errors(run_dir, log):
            log("[ERROR] 샤드 로그에도 에러 표식이 없다 - 추론이 시작조차 "
                "못했거나(설정/경로 문제) 외부에서 종료된 것으로 보인다 "
                "(OOM kill 등은 로그를 남기지 않는다).")
        log.close()
        raise SystemExit(1)

    log(f"[info] labels  : {args.labels}  ({len(labels)} clips)")
    log(f"[info] results : {run_dir}  ({len(results)} clips)")
    run_cfg = log_run_config(run_dir, log)
    if meta:
        log(f"[info] labeled_by={meta.get('labeled_by','?')} "
            f"date={meta.get('date','?')}")
    if skipped:
        log(f"[warn] {len(skipped)} label(s) missing categories - skipped")

    common = [u for u in labels if u in results]
    missing = [u for u in labels if u not in results]
    log(f"[info] matched : {len(common)}/{len(labels)}")
    if missing:
        log(f"[warn] {len(missing)} labelled clip(s) not in results, e.g. "
            f"{missing[:3]}")

    # 빠진 클립이 있으면 대개 샤드가 죽은 것이다. 원인을 여기 남긴다.
    failed = scan_shard_errors(run_dir, log)
    if failed and missing:
        log(f"[ERROR] 아래 점수는 {len(common)}개 클립만 반영한 것이라 "
            f"성능 비교에 쓰면 안 된다.")
        log("")

    # 카테고리 이름이 taxonomy 와 어긋나면 그 카테고리의 F1 이 0 으로 나온다.
    # 실제 성능이 아니라 버전 불일치인데 숫자만 보면 구분이 안 되므로, 채점
    # 전에 짚어준다. 실측 사례: 예전 실행이 소문자 'cyclist' 를 쓰던 시절의
    # 결과를 대문자 'Cyclist' 라벨로 채점하자 F1=0.00 이 나왔다.
    # 검증 기준은 "이 실행이 실제로 쓴" 카테고리 정의여야 한다. 채점기가
    # 자기 기본값으로 검사하면, D 로 돌린 결과를 C 기준으로 훑으면서
    # 멀쩡한 이름을 "taxonomy 에 없다" 고 경고하게 된다.
    SCENE_JSON = Path((run_cfg or {}).get("key", {}).get("scene_json")
                      or CONFIG_SCENE_JSON)
    if not SCENE_JSON.is_absolute():
        SCENE_JSON = ROOT / SCENE_JSON
    group, n_drop, n_normal = restrict_to_group(labels, run_cfg, SCENE_JSON)
    if group != "all":
        log(f"[info] group   : {group} - 이 실행이 다루지 않은 상위 카테고리의 "
            f"GT 카테고리 {n_drop}개를 채점에서 뺌(그 결과 Normal 이 된 클립 "
            f"{n_normal}개)")
    # 0~4 밖의 묶음 점수 경고는 이 실행이 다룬 상위 카테고리 것만 낸다 -
    # Dynamic object 만 돌린 실행에서 아직 안 매긴 Driving environment 라벨
    # 경고가 수백 줄 나오면 정작 봐야 할 경고가 묻힌다.
    hits = [h for h in mismatches["out_of_range"]
            if group == "all" or group_key(h[1]) == group]
    if hits:
        log(f"[warn] 라벨 {len(hits)}건: 묶음 점수가 0~4 밖이라 채점에서 뺌 - "
            + ", ".join(f"{u[:8]}:{g}={n}" for u, g, n in hits[:10])
            + (" ..." if len(hits) > 10 else ""))
    taxonomy = set()
    # 카테고리 -> 묶음. 3) 절에서 그 카테고리가 어느 rubric 으로 채점됐는지
    # 함께 찍으려고 들고 있는다.
    scenario_of = {}
    if SCENE_JSON.exists():
        scene = json.loads(SCENE_JSON.read_text(encoding="utf-8"))
        taxonomy = {c["name"] for s in scene["special"]["scenarios"]
                    for c in s["categories"]}
        scenario_of = {c["name"]: s["name"]
                       for s in scene["special"]["scenarios"]
                       for c in s["categories"]}
        lab_names = {c for u in common for c in labels[u]["categories"]}
        res_names = {c for u in common for c in results[u]["categories"]}
        for tag, names in (("labels", lab_names), ("results", res_names)):
            bad = names - taxonomy
            if bad:
                log(f"[warn] {tag} use category names not in "
                    f"{SCENE_JSON.name}: {sorted(bad)}")
        only_lab = sorted(lab_names - res_names)
        only_res = sorted(res_names - lab_names)
        if only_lab and only_res:
            log(f"[warn] names present only in labels {only_lab} vs only in "
                f"results {only_res} - if these look like the same category "
                f"spelled differently, the run predates the current taxonomy "
                f"and its scores below are meaningless for those rows.")
    if not common:
        log("[error] no overlap between labels and results")
        log.close()
        return

    # ---------------- 1) VERDICT ----------------
    tp = fp = fn = tn = 0
    for u in common:
        t, p = bool(labels[u]["categories"]), bool(results[u]["categories"])
        tp += t and p
        fp += (not t) and p
        fn += t and (not p)
        tn += (not t) and (not p)
    P, R, F = prf(tp, fp, fn)
    spec = tn / (tn + fp) if (tn + fp) else 0.0

    log("")
    log("=" * 68)
    log("1) VERDICT  (Special = has >=1 category)")
    log("=" * 68)
    log(f"  truth: special={tp+fn}  normal={tn+fp}")
    log(f"  TP={tp}  FP={fp}  FN={fn}  TN={tn}")
    log(f"  accuracy    : {(tp+tn)/len(common):6.1%}")
    log(f"  precision   : {P:6.1%}   recall: {R:6.1%}   F1: {F:6.1%}")
    log(f"  specificity : {spec:6.1%}")
    # 유병률 보정 - recall/specificity 는 표본 비율과 무관하다는 성질을 쓴다
    pv = args.prevalence
    tp_r, fp_r = R * pv, (1 - spec) * (1 - pv)
    P_adj = tp_r / (tp_r + fp_r) if (tp_r + fp_r) else 0.0
    F_adj = 2 * P_adj * R / (P_adj + R) if (P_adj + R) else 0.0
    log("")
    log(f"  adjusted to real prevalence ({pv:.1%} special):")
    log(f"    precision : {P_adj:6.1%}   recall: {R:6.1%}   F1: {F_adj:6.1%}")
    log("    (label set is 50:50, so the raw precision above is optimistic;")
    log("     this row estimates what you would get on all 1,998 clips)")

    # ---------------- 2) CATEGORIES ----------------
    per_clip = [f1_set(labels[u]["categories"], results[u]["categories"])
                for u in common]
    sp = [u for u in common if labels[u]["categories"]]
    per_clip_sp = [f1_set(labels[u]["categories"], results[u]["categories"])
                   for u in sp]

    # taxonomy 에 정의된 카테고리는 정답도 예측도 0건이어도 모두 표기한다.
    # 빠져 있으면 "모델이 한 번도 못 찾은 카테고리"와 "애초에 목록에 없는
    # 카테고리"가 로그에서 구분되지 않는다 - 실측(20260818)에서 실제로
    # Unusual Traffic Pattern 이 표에서 사라져 왜 없는지 되짚어야 했다.
    # 라벨/예측에만 있고 taxonomy 에 없는 이름도 빠뜨리지 않고 함께 싣는다
    # (위 [warn] 이 가리키는 버전 불일치를 표에서도 확인할 수 있어야 한다).
    names = sorted(taxonomy
                   | {c for u in common for c in labels[u]["categories"]}
                   | {c for u in common for c in results[u]["categories"]})
    rows, micro = [], [0, 0, 0]
    per_cat = {}                      # 카테고리 -> {TP/FP/FN: [uuid, ...]}
    for c in names:
        hit = [u for u in common if c in labels[u]["categories"]
               and c in results[u]["categories"]]
        false_pos = [u for u in common if c not in labels[u]["categories"]
                     and c in results[u]["categories"]]
        false_neg = [u for u in common if c in labels[u]["categories"]
                     and c not in results[u]["categories"]]
        per_cat[c] = {"TP": hit, "FP": false_pos, "FN": false_neg}
        t = len(hit) + len(false_neg)
        ctp, cfp, cfn = len(hit), len(false_pos), len(false_neg)
        micro[0] += ctp; micro[1] += cfp; micro[2] += cfn
        rows.append((c, t, *prf(ctp, cfp, cfn), ctp, cfp, cfn))

    log("")
    log("=" * 68)
    log("2) CATEGORIES  (multi-label)")
    log("=" * 68)
    log(f"  per-clip F1, all {len(common)} clips  : {sum(per_clip)/len(per_clip):.3f}")
    if per_clip_sp:
        log(f"  per-clip F1, {len(sp)} special only : "
            f"{sum(per_clip_sp)/len(per_clip_sp):.3f}")
    log(f"  micro F1  : {prf(*micro)[2]:.3f}")
    scored = [r for r in rows if r[1] >= args.min_support]
    if scored:
        log(f"  macro F1  : {sum(r[4] for r in scored)/len(scored):.3f}"
            f"   (over {len(scored)} categories with >={args.min_support} labels)")
    log("")
    log(f"  {'category':<32}{'n':>4}{'P':>8}{'R':>8}{'F1':>8}"
        f"{'TP':>5}{'FP':>5}{'FN':>5}")
    log("  " + "-" * 66)
    for c, t, p, r, f, ctp, cfp, cfn in sorted(rows, key=lambda x: -x[1]):
        log(f" {c:<32}{t:>4}{p:>8.2f}{r:>8.2f}{f:>8.2f}"
            f"{ctp:>5}{cfp:>5}{cfn:>5}")
    write_category_lists(run_dir, per_cat, log)

    # ---------------- 3) GROUP SCORES ----------------
    # 묶음(Dynamic object / Driving environment)마다 클립당 0~4 점수 하나.
    #
    # 0 은 "그 묶음의 특수 카테고리 없음"이라는 기준표의 칸이다. 그래서
    # Normal 클립도 0/0 으로 채점에 들어가고, 탐지를 놓친 것도 예측 0 으로
    # 자연히 잡힌다 - 예전 카테고리별 점수에서 따로 만들던 pred0 이 이제
    # 기준표 안에 있다.
    #
    # 채점 대상은 GT 와 예측이 둘 다 그 묶음 점수를 가진 클립이다. GT 를
    # 아직 안 매긴 클립(키 없음/null/-1)은 빠진다.
    #
    # 묶음 점수와 카테고리 목록의 어긋남도 센다: 그 묶음 카테고리를 적고도
    # 0 이거나, 하나도 적지 않고 1 이상인 경우. 프롬프트가 "이름을 댄 묶음은
    # 1 이상, 대지 않은 묶음은 0" 을 요구하므로, 이 수가 크면 모델이 그
    # 규칙을 못 지키는 것이다. 라벨 쪽 어긋남도 함께 내 라벨 실수를 잡는다.
    groups = list(dict.fromkeys(
        [g for u in common for g in labels[u]["scores"]]
        + [g for u in common for g in results[u]["scores"]]))
    if groups and any(results[u]["scores"] for u in common):
        log("")
        log("=" * 68)
        log("3) GROUP SCORES  (0-4 per group; 0 = no type of that group)")
        log("=" * 68)

        def conflicts(rec):
            bad = []
            for g, n in rec["scores"].items():
                has = any(scenario_of.get(c) == g for c in rec["categories"])
                if (n == 0 and has) or (n >= 1 and not has):
                    bad.append(g)
            return bad

        all_pairs = []
        rows = []
        for g in groups:
            pairs = [(labels[u]["scores"][g], results[u]["scores"][g])
                     for u in common
                     if g in labels[u]["scores"] and g in results[u]["scores"]]
            if not pairs:
                continue
            all_pairs += pairs
            log("")
            log(f" {g}")
            tier_block(g, pairs, log, values=group_values(g)
                       if g in GROUP_RUBRICS else TIER_VALUES)
            rows.append((g, len(pairs), _mse(pairs),
                         sum(a == b for a, b in pairs) / len(pairs)))
        if len(rows) > 1:
            log("")
            log(" ALL groups")
            tier_block("all", all_pairs, log)
        if rows:
            log("")
            log(f"  {'group':<28}{'n':>5}{'MSE':>8}{'Acc':>7}")
            log("  " + "-" * 48)
            for g, n, mse, acc in rows:
                log(f"  {g:<28}{n:>5}{mse:>8.3f}{acc:>7.2f}")

        if scenario_of:
            for tag, src in (("pred", results), ("GT", labels)):
                hits = [(u, g) for u in common for g in conflicts(src[u])]
                log("")
                log(f"  [{tag}] 묶음 점수 <-> 카테고리 어긋남: {len(hits)}건"
                    + (" - " + ", ".join(f"{u[:8]}:{g}" for u, g in hits[:8])
                       + (" ..." if len(hits) > 8 else "") if hits else ""))

    # ---------------- 5) WEATHER ----------------
    # 등급과 달리 edge-case 여부와 무관한 축이라(평범한 클립도 비가 오면
    # 높다) SPECIAL 만 따로 내지 않는다. 대신 4축을 나란히 놓은 요약표를
    # 붙인다 - 축마다 표를 다시 읽지 않고 "어느 축이 틀리는가"를 보려는 것.
    diff_pairs = {}
    for key, _name in DIFFICULTY_AXES:
        diff_pairs[key] = [(labels[u][key], results[u][key]) for u in common
                           if labels[u].get(key) is not None
                           and results[u].get(key) is not None]

    if any(diff_pairs.values()):
        log("")
        log("=" * 68)
        log(f"5) WEATHER  ({DIFFICULTY_MIN}-{DIFFICULTY_MAX})")
        log("=" * 68)
        for key, name in DIFFICULTY_AXES:
            log("")
            log(f" {name} ({key})")
            tier_block(key, diff_pairs[key], log, DIFFICULTY_VALUES)

        log("")
        log("-" * 68)
        log(f"  {'AXIS':<26}{'N':>6}{'MSE':>8}{'EXACT':>8}{'+-1':>8}"
            f"{'GT~':>7}{'PRED~':>7}")
        log("  " + "-" * 62)
        for key, name in DIFFICULTY_AXES:
            p = diff_pairs[key]
            if not p:
                log(f"  {name:<26}{0:>6}{'-':>8}{'-':>8}{'-':>8}{'-':>7}{'-':>7}")
                continue
            m = len(p)
            mse = sum((t - q) ** 2 for t, q in p) / m
            exact = sum(t == q for t, q in p) / m
            near = sum(abs(t - q) <= 1 for t, q in p) / m
            gt_mean = sum(t for t, _ in p) / m
            pr_mean = sum(q for _, q in p) / m
            log(f"  {name:<26}{m:>6}{mse:>8.3f}{exact:>7.1%}{near:>8.1%}"
                f"{gt_mean:>7.2f}{pr_mean:>7.2f}")
        log("  " + "-" * 62)
        log("  GT~ / PRED~ 는 평균값이다. 둘이 크게 벌어지면 그 축은 한쪽으로"
            " 치우쳐 찍고 있다는 뜻.")
        log("  축은 서로 독립으로 매기므로 합이 전체 난이도가 되지는 않는다.")

    log("")
    log(f"[saved] {args.out or run_dir / 'evaluation.log'}")
    log.close()


if __name__ == "__main__":
    main()
